
-- --------------------------------------------------------

--
-- Table structure for table `concernedpublic`
--

CREATE TABLE `concernedpublic` (
  `CPID` int(20) NOT NULL,
  `VID` int(20) NOT NULL,
  `Fname` varchar(20) NOT NULL,
  `Lname` varchar(20) NOT NULL,
  `street` varchar(20) DEFAULT NULL,
  `aptNum` varchar(5) DEFAULT NULL,
  `city` varchar(20) DEFAULT NULL,
  `zip` varchar(15) DEFAULT NULL,
  `State/Prov` varchar(20) DEFAULT NULL,
  `Country` varchar(20) DEFAULT NULL,
  `Photo` longblob,
  `Phone` varchar(20) DEFAULT NULL,
  `Subscrib` tinyint(1) NOT NULL DEFAULT '0',
  `Email` varchar(30) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
