
--
-- Indexes for dumped tables
--

--
-- Indexes for table `concernedpublic`
--
ALTER TABLE `concernedpublic`
  ADD PRIMARY KEY (`CPID`);

--
-- Indexes for table `fam`
--
ALTER TABLE `fam`
  ADD PRIMARY KEY (`FID`),
  ADD UNIQUE KEY `VID` (`VID`);

--
-- Indexes for table `login`
--
ALTER TABLE `login`
  ADD PRIMARY KEY (`E_mail`);

--
-- Indexes for table `viccontacts`
--
ALTER TABLE `viccontacts`
  ADD PRIMARY KEY (`VCID`);

--
-- Indexes for table `victim`
--
ALTER TABLE `victim`
  ADD PRIMARY KEY (`VID`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `concernedpublic`
--
ALTER TABLE `concernedpublic`
  MODIFY `CPID` int(20) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `fam`
--
ALTER TABLE `fam`
  MODIFY `FID` int(20) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `viccontacts`
--
ALTER TABLE `viccontacts`
  MODIFY `VCID` int(20) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `victim`
--
ALTER TABLE `victim`
  MODIFY `VID` int(15) NOT NULL AUTO_INCREMENT;