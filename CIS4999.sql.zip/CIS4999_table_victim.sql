
-- --------------------------------------------------------

--
-- Table structure for table `victim`
--

CREATE TABLE `victim` (
  `VID` int(15) NOT NULL,
  `Fname` varchar(20) NOT NULL,
  `Lname` varchar(20) NOT NULL,
  `FathersName` varchar(40) NOT NULL,
  `MothersName` int(40) NOT NULL,
  `Photo` blob NOT NULL,
  `Race` varchar(20) NOT NULL,
  `hairColor` int(20) NOT NULL,
  `eyeColor` int(20) NOT NULL,
  `DoB` date NOT NULL,
  `Weight` int(3) NOT NULL,
  `Height` int(3) NOT NULL,
  `Cphone` int(12) DEFAULT NULL,
  `facebook` varchar(20) DEFAULT NULL,
  `instagram` int(20) DEFAULT NULL,
  `distMark` varchar(300) DEFAULT NULL,
  `LastLocation` varchar(40) NOT NULL,
  `LastDate` date NOT NULL,
  `Notes` varchar(400) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
