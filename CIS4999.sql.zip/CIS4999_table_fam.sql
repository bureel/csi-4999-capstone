
-- --------------------------------------------------------

--
-- Table structure for table `fam`
--

CREATE TABLE `fam` (
  `FID` int(20) NOT NULL,
  `E-Mail` varchar(30) NOT NULL,
  `Fname` varchar(20) NOT NULL,
  `Lname` varchar(20) NOT NULL,
  `Street` varchar(20) NOT NULL,
  `aptNum` varchar(5) DEFAULT NULL,
  `City` varchar(20) NOT NULL,
  `State/Prov` text NOT NULL,
  `Country` text NOT NULL,
  `Hphone` varchar(20) DEFAULT NULL,
  `Cphone` varchar(20) DEFAULT NULL,
  `Wphone` varchar(20) DEFAULT NULL,
  `VID` int(15) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
