
-- --------------------------------------------------------

--
-- Table structure for table `viccontacts`
--

CREATE TABLE `viccontacts` (
  `VCID` int(20) NOT NULL,
  `VID` int(20) NOT NULL,
  `Fname` varchar(20) NOT NULL,
  `Lname` varchar(20) NOT NULL,
  `akaName` varchar(20) DEFAULT NULL,
  `StreetNumber` varchar(10) DEFAULT NULL,
  `Street` int(20) DEFAULT NULL,
  `aptNum` int(5) DEFAULT NULL,
  `zip` int(15) DEFAULT NULL,
  `State/prov` int(20) NOT NULL,
  `Hphone` int(20) DEFAULT NULL,
  `Cphone` int(20) DEFAULT NULL,
  `Wphone` int(20) DEFAULT NULL,
  `facebook` varchar(30) DEFAULT NULL,
  `twitter` varchar(30) DEFAULT NULL,
  `instagram` varchar(30) DEFAULT NULL,
  `Country` varchar(20) NOT NULL,
  `City` varchar(20) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
